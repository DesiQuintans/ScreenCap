
ScreenCap v1
Author:			Daniel Unterberger, Philippe Lhoste, and Desi Quintans <me@desiquintans.com>
Website:		http://www.desiquintans.com

Script Function:
	This script lets you automatically capture the contents of your computer screen, without
	the use of external programs. It is meant to be a portable tool that lives on a flash
	drive, requiring no installation or setup.

Compatibility:
	- Windows 95/XP/Vista/7

Usage:
	Copy ScreenCap.exe wherever you want it (usually a flash drive), and run it. Press the Print
	Screen key (it's above the Insert/Home/Page Up keys on your keyboard) to automatically save
	what you see on the screen. It will save in lossless PNG format in the Screenshots
	folder. To quit, right-click the Camera icon in the taskbar and select Exit.

Notes:
	ScreenCap will probably have trouble capturing images from DirectX applications (namely
	video games). This is for reasons related to image buffering etc. 

Credits:
   Original code by Daniel Unterberger
		http://www.autohotkey.com/forum/viewtopic.php?t=12012
   Using the GDI+ Helper library by Philippe Lhoste
		http://www.autohotkey.com/forum/viewtopic.php?t=11860
   User prompts added by Desi Quintans
		http://www.desiquintans.com

Changelog:
v1: 	Initial (and final) release.